#ifndef _DOWNLOAD_FX3_
#define _DOWNLOAD_FX3_

int fx3_usbboot_download(libusb_device_handle *handle, char *filename);

#endif
