#!/bin/bash
#####################################################################################################################
# Description : This script installs all the necessary files (libraries, firmwares, udev, include) on Linux machine. 
# Written by  : Jan Soldan (astrosoft@email.cz)
# Version     : 1.00
# Date        : 6/2017
#####################################################################################################################

# 1. install shared libs and links
cp -d ../lib/* /usr/local/lib

# 2. install firmware
cp ../firmware/* /lib/firmware/qhy

# 3. install udev files
cp ../udev/* /etc/udev/rules.d

# 4. install fxload with the FX3 support
cp ../fx3load/a3load.hex /usr/share/usb
cp ../fx3load/fxload /sbin

