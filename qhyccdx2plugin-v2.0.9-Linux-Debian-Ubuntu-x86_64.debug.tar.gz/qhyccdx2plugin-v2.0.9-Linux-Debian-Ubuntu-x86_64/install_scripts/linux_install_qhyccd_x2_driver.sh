#!/bin/bash
#####################################################################################################################
# Description : This script installs all the necessary files (libraries, firmwares, udev, include) on Linux machine. 
# Written by  : Jan Soldan (astrosoft@email.cz)
# Version     : 1.03
# Date        : 11/2017
#####################################################################################################################

# install firmware
mkdir -p /usr/local/lib/qhy/firmware
cp -p ../firmware/* /usr/local/lib/qhy/firmware

# install LIBQHYX2PLUGIN
rm -rf ../../Resources/Common/PlugIns/CameraPlugIns/libQHYCCDX2* 
cp -d ../CameraPlugIns/libQHYCCDX2Plugin.* ../../Resources/Common/PlugIns/CameraPlugIns

# install QTCCD.ui
cp ../CameraPlugIns/QHYCCD.ui ../../Resources/Common/PlugIns/CameraPlugIns

# install cameralist QHYCCD.txt
rm -rf ../../Resources/Common/Miscellaneous\ Files/cameralist\ QHYCCD* 
cp ../MiscellaneousFiles/cameralist\ QHYCCD.txt ../../Resources/Common/Miscellaneous\ Files

# install udev files
cp ../udev/* /etc/udev/rules.d
cp ../udev/* /lib/udev/rules.d

# install fxload with the FX3 support
cp ../fx3load/a3load.hex /usr/share/usb
cp ../fx3load/fxload /sbin
