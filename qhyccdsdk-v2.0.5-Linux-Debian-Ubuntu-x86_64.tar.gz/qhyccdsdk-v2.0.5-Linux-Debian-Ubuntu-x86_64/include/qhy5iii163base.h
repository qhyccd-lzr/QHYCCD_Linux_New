/*
 QHYCCD SDK
 
 Copyright (c) 2014 QHYCCD.
 All Rights Reserved.
 
 This program is free software; you can redistribute it and/or modify it
 under the terms of the GNU General Public License as published by the Free
 Software Foundation; either version 2 of the License, or (at your option)
 any later version.
 
 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 more details.
 
 You should have received a copy of the GNU General Public License along with
 this program; if not, write to the Free Software Foundation, Inc., 59
 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 
 The full GNU General Public License is included in this distribution in the
 file called LICENSE.
 */

#include "qhy5iiiddrcoolbase.h"

#ifndef _QHY5III163BASE_
#define _QHY5III163BASE_

class QHY5III163BASE : public QHY5IIIDDRCOOLBASE {
public:
    QHY5III163BASE();
    virtual ~QHY5III163BASE();

    uint32_t BeginSingleExposure(qhyccd_handle *pDevHandle);
    uint32_t CancelExposing(qhyccd_handle *pDevHandle);
    uint32_t CancelExposingAndReadout(qhyccd_handle *pDevHandle);
    uint32_t BeginLiveExposure(qhyccd_handle *pDevHandle);
    uint32_t StopLiveExposure(qhyccd_handle *pDevHandle);
    uint32_t GetSingleFrame(qhyccd_handle *pDevHandle, uint32_t *pW, uint32_t *pH, uint32_t *pBpp, uint32_t *pChannels, uint8_t *pImgData);  
    static void ExposureThreadRoutine(void *pDevHandle);
    void StartExposureThread(qhyccd_handle *pDevHandle);
    
    void writeCMOS(qhyccd_handle *pDevHandle, int addr, int value);
    uint32_t GetUsedDdr(qhyccd_handle *pDevHandle, uint32_t *pDdr);
    uint32_t SetChipGain(qhyccd_handle *pDevHandle, double gain);
    uint32_t DisConnectCamera(qhyccd_handle *pDevHandle);
    uint32_t SetChipWBRed(qhyccd_handle *pDevHandle, double red);
    uint32_t SetChipWBBlue(qhyccd_handle *pDevHandle, double blue);
    uint32_t SetChipExposeTime(qhyccd_handle *pDevHandle, double i);
    void SetChipExposeTime_Internal(qhyccd_handle *pDevHandle,double i);

    uint32_t GetControlMinMaxStepValue(CONTROL_ID controlId, double *min, double *max, double *step);
    uint32_t SetChipOffset(qhyccd_handle *pDevHandle, double offset);
    uint32_t SetChipBitsMode(qhyccd_handle *pDevHandle, uint32_t bits);
    uint32_t SetChipResolution(qhyccd_handle *pDevHandle, uint32_t x, uint32_t y, uint32_t xsize, uint32_t ysize);
    uint32_t SetFocusSetting(qhyccd_handle *pDevHandle, uint32_t focusCenterX, uint32_t focusCenterY);
    uint32_t SetChipUSBTraffic(qhyccd_handle *pDevHandle,uint32_t i);
    uint32_t GeDDRBufferThreshold();
    void initcmos(qhyccd_handle *pDevHandle);
    void UpdateParameters(qhyccd_handle *pDevHandle);
    void ResetParameters();
    void WriteCMOS(qhyccd_handle *pDevHandle,uint16_t index,uint16_t val);
    void WriteCMOSSHS(qhyccd_handle *pDevHandle,uint32_t val);

private:
//    static constexpr double ACTIVE_PIXEL_WIDTH_DIMESION_MM = 17.6472; 
//    static constexpr const double ACTIVE_PIXEL_HEIGHT_DIMENSION_MM = 13.3228; 
//    static constexpr const double PIXEL_SIZE_UM = 3.8;
//    static constexpr const double INIT_EXPOSURE_TIME = 20000.0;
//    static constexpr const double CAM_OFFSET = 64.0;
//    static const int TOTAL_PIXELS_WIDTH = 4720;
//    static const int TOTAL_PIXELS_HEIGHT = 3522;
//    static const uint8_t USB_ENDPOINT = 0x81;
//    static const uint32_t CAM_BITS = 16;
//    static const uint32_t USB_PACKET_LENGTH = 4096;
//    static const uint32_t USB_TIMEOUT = 1000;

    uint8_t oldcamddr;
    uint8_t oldlockframe, lockframe;
    uint8_t oldampv_onff, ampv_onff;
    
    uint16_t digital_gain, analog_gain;
    
    uint32_t hmax_ref, vmax_ref;
    uint32_t vmax, hmax, oldvmax, oldhmax;
    uint32_t framelength, oldframelength;
    uint32_t oldchipoutputsizex, oldchipoutputsizey, oldchipoutputbits;
    uint32_t patchvnumber, oldpatchvnumber;
    uint32_t oldeleshutter, eleshutter;
    uint32_t oldcamoffset;
    uint32_t oldusbtraffic;
    uint32_t oldampv_min, ampv_min, oldampv_max, ampv_max;
    uint32_t ApproxDDR;
    uint32_t ApproxDDR_Target;
    uint32_t shr,svr,spl; //,oldshr,oldsvr,oldspl; // not used
    uint32_t sleepframes; //,oldsleepframes,sleepmode,initsingleframe; // not used
    int imageY;
    double pllratio, oldpllratio; //!< inter pll ratio
    double m_oldcamgain;

//#ifdef LINUX
//    pthread_t m_expThreadHandle;
//#endif

};
#endif
