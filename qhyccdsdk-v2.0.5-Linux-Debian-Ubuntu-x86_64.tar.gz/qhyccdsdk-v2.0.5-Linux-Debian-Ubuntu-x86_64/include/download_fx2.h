#ifndef _DOWNLOAD_FX2_
#define _DOWNLOAD_FX2_

int fx2_ram_download(libusb_device_handle *handle, char *filename, unsigned char vendor_command);

#endif
