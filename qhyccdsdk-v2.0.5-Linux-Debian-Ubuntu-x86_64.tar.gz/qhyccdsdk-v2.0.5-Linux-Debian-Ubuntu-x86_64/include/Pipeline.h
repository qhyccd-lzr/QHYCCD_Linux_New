#pragma once

uint32_t __stdcall PipelineThread(void* pParams);
