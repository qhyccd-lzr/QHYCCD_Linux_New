/*
 ## Cypress CyAPI C++ library version number header file (VersionNo.h)
 ## =======================================================
 ##
 ##  Copyright Cypress Semiconductor Corporation, 2009-2012,
 ##  All Rights Reserved
 ##  UNPUBLISHED, LICENSED SOFTWARE.
 ##
 ##  CONFIDENTIAL AND PROPRIETARY INFORMATION
 ##  WHICH IS THE PROPERTY OF CYPRESS.
 ##
 ##  Use of this file is governed
 ##  by the license agreement included in the file
 ##
 ##  <install>/license/license.rtf
 ##
 ##  where <install> is the Cypress software
 ##  install root directory path.
 ##
 ## =======================================================
*/
#define FILEVER        1,2,1,0
#define PRODUCTVER     1,2,1,0
#define STRFILEVER     "1, 2, 1, 0"
#define STRPRODUCTVER  "1, 2, 1, 0"
#define STRFILEVER_ASSENBLY   "1.2.1.0"
