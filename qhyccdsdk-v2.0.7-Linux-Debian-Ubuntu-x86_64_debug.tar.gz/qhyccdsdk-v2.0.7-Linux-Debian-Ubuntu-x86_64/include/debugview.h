

void OutputDebugPrintf(const char * strOutputString,...);