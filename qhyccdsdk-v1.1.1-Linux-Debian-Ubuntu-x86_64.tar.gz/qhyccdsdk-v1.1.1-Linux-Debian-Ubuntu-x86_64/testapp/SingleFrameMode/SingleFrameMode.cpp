
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "../../include/qhyccd.h"

#define VERSION 1.00

int main(int argc, char *argv[]) {

    int USB_TRAFFIC = 10;
    int CHIP_GAIN = 10;
    int CHIP_OFFSET = 140;
    int EXPOSURE_TIME = 20000;
    int camBinX = 1;
    int camBinY = 1;
    
    double chipWidthMM;
    double chipHeightMM;
    double pixelWidthUM;
    double pixelHeightUM;
    
    unsigned int roiStartX;
    unsigned int roiStartY;
    unsigned int roiSizeX;
    unsigned int roiSizeY;
    
    unsigned int overscanStartX;
    unsigned int overscanStartY;
    unsigned int overscanSizeX;
    unsigned int overscanSizeY;
    
    unsigned int effectiveStartX;
    unsigned int effectiveStartY;
    unsigned int effectiveSizeX;
    unsigned int effectiveSizeY;
    
    unsigned int maxImageSizeX;
    unsigned int maxImageSizeY;
    unsigned int bpp;
    unsigned int channels;
    
    unsigned char *pImgData = 0;
	char camId[32];
	int retVal;
	
    const char *pFirmware = "/usr/local/lib/qhy";
    
    printf("SingleFrameMode, Version: %.2f\n", VERSION);
     
    do {
    	
    	// First of all, we have to call the InitQHYCCDResource function to set internal 
    	// data structures and to initialize the low level libusb library.
    	retVal = InitQHYCCDResource();
    	if (QHYCCD_SUCCESS == retVal) {
    		printf("SDK resources initialized.\n");
    	} else {
    		printf("Cannot initialize SDK resources, error: %d\n", retVal);
    		continue;
    	}

    	//    MacOSX
    	//    printf("OSXInitQHYCCDFirmware start...\n");
    	//    OSXInitQHYCCDFirmware(pFirmware);
    	//    printf("OSXInitQHYCCDFirmware end...\n");
    
    	// scan cameras
    	int camCount = ScanQHYCCD();
    	if (camCount > 0) {
    		printf("Number of QHYCCD cameras found: %d \n", camCount);
    	} else {
    		printf("No QHYCCD camera found, please check USB or power.\n");
    		continue;
    	}

    	for (int cycle = 0; cycle < 1; cycle++) {

			printf("===================================================\n");
    		printf("cycle no.: %d\n", (cycle + 1));
    		
    		// iterate over all attached cameras and take one image from each camera
    		for (int i = 0; i < camCount; i++) {
    		
    			retVal = GetQHYCCDId(i, camId);
    			if (QHYCCD_SUCCESS != retVal) {
    				printf("Cannot connect to camera Idx: %d,  cameraID = %s\n", (i + 1), camId);
    				continue;
    			}
       
    			// open camera
    			qhyccd_handle *pCamHandle = OpenQHYCCD(camId);
    			if (NULL != pCamHandle) {
    				printf("---------------------------------------------------\n");
    				printf("Idx: %d, OpenQHYCCD %s success.\n", (i+1), camId);
    			} else {
    				printf("Idx: %d, OpenQHYCCD failure.\n", (i+1));
    				continue;
    			}
       
    			// set single frame mode
    			int mode = 0;
    			retVal = SetQHYCCDStreamMode(pCamHandle, mode);
    			if (QHYCCD_SUCCESS == retVal) {
    				printf("SetQHYCCDStreamMode set to: %d, success.\n", mode);
    			} else {
    				printf("SetQHYCCDStreamMode: %d failure, error: %d\n", mode, retVal);
    				break;
    			}

    			// initialize camera
    			retVal = InitQHYCCD(pCamHandle);
    			if (QHYCCD_SUCCESS == retVal) {
    				printf("InitQHYCCD success.\n");
    			} else {
    				printf("InitQHYCCD faililure, error: %d\n", retVal);
    				break;
    			}
       
    			// get overscan area
    			retVal = GetQHYCCDOverScanArea(pCamHandle, &overscanStartX, &overscanStartY, &overscanSizeX, &overscanSizeY);
    			if (QHYCCD_SUCCESS == retVal) {
    				printf("GetQHYCCDOverScanArea:\n");
    				printf("Overscan Area startX x startY : %d x %d\n", overscanStartX, overscanStartY);
    				printf("Overscan Area sizeX  x sizeY  : %d x %d\n", overscanSizeX, overscanSizeY);
    			} else {
    				printf("GetQHYCCDOverScanArea failure, error: %d\n", retVal);
    				break;
    			}
       
    			// get effective area
    			retVal = GetQHYCCDOverScanArea(pCamHandle, &effectiveStartX, &effectiveStartY, &effectiveSizeX, &effectiveSizeY);
    			if (QHYCCD_SUCCESS == retVal) {
    				printf("GetQHYCCDEffectiveArea:\n");
    				printf("Effective Area startX x startY: %d x %d\n", effectiveStartX, effectiveStartY);
    				printf("Effective Area sizeX  x sizeY : %d x %d\n", effectiveSizeX, effectiveSizeY);
    			} else {
    				printf("GetQHYCCDOverScanArea failure, error: %d\n", retVal);
    				break;
    			}

    			// get chip info
    			retVal = GetQHYCCDChipInfo(pCamHandle, &chipWidthMM, &chipHeightMM, &maxImageSizeX, &maxImageSizeY, &pixelWidthUM, &pixelHeightUM, &bpp);
    			if (QHYCCD_SUCCESS == retVal) {
    				printf("GetQHYCCDChipInfo:\n");
    				printf("Effective Area startX x startY: %d x %d\n", effectiveStartX, effectiveStartY);
    				printf("Chip  size width x height     : %.3f x %.3f [mm]\n", chipWidthMM, chipHeightMM);
    				printf("Pixel size width x height     : %.3f x %.3f [um]\n", pixelWidthUM, pixelHeightUM);
    				printf("Image size width x height     : %d x %d\n", maxImageSizeX, maxImageSizeY);
    			} else {
    				printf("GetQHYCCDChipInfo failure, error: %d\n", retVal);
    				break;
    			}
    
    			// set ROI
    			roiStartX = 0;
    			roiStartY = 0;
    			roiSizeX = maxImageSizeX;
    			roiSizeY = maxImageSizeY;

    			// check color camera
    			retVal = IsQHYCCDControlAvailable(pCamHandle, CAM_COLOR);
    			if (retVal == BAYER_GB || retVal == BAYER_GR || retVal == BAYER_BG || retVal == BAYER_RG) {
    				printf("This is a color camera.\n");
    				SetQHYCCDDebayerOnOff(pCamHandle, true);
    				SetQHYCCDParam(pCamHandle, CONTROL_WBR, 20);
    				SetQHYCCDParam(pCamHandle, CONTROL_WBG, 20);
    				SetQHYCCDParam(pCamHandle, CONTROL_WBB, 20);
    			} else {
    				printf("This is a mono camera.\n");
    			}

    			// check traffic
    			retVal = IsQHYCCDControlAvailable(pCamHandle, CONTROL_USBTRAFFIC);
    			if (QHYCCD_SUCCESS == retVal) {
    				retVal = SetQHYCCDParam(pCamHandle, CONTROL_USBTRAFFIC, USB_TRAFFIC);
    				if (QHYCCD_SUCCESS == retVal) {
    					printf("SetQHYCCDParam CONTROL_USBTRAFFIC    set to: %d, success.\n", USB_TRAFFIC);
    				} else {
    					printf("SetQHYCCDParam CONTROL_USBTRAFFIC failure, error: %d\n", retVal);
    					getchar();
    					break;
    				}
    			}

    			// check gain
    			retVal = IsQHYCCDControlAvailable(pCamHandle, CONTROL_GAIN);
    			if (QHYCCD_SUCCESS == retVal) {
    				retVal = SetQHYCCDParam(pCamHandle, CONTROL_GAIN, CHIP_GAIN);
    				if (retVal == QHYCCD_SUCCESS) {
    					printf("SetQHYCCDParam CONTROL_GAIN          set to: %d, success\n", CHIP_GAIN);
    				} else {
    					printf("SetQHYCCDParam CONTROL_GAIN failure, error: %d\n", retVal);
    					break;
    				}
    			}

    			// check offset
    			retVal = IsQHYCCDControlAvailable(pCamHandle, CONTROL_OFFSET);
    			if (QHYCCD_SUCCESS == retVal) {
    				retVal = SetQHYCCDParam(pCamHandle, CONTROL_OFFSET, CHIP_OFFSET);
    				if (QHYCCD_SUCCESS == retVal) {
    					printf("SetQHYCCDParam CONTROL_OFFSET        set to: %d, success.\n", CHIP_OFFSET);
    				} else {
    					printf("SetQHYCCDParam CONTROL_OFFSET failed.\n");
    					break;
    				}
    			}

    			// set exposure time
    			retVal = SetQHYCCDParam(pCamHandle, CONTROL_EXPOSURE, EXPOSURE_TIME);
    			if (QHYCCD_SUCCESS == retVal) {
    				printf("SetQHYCCDParam CONTROL_EXPOSURE [us] set to: %d, success.\n", EXPOSURE_TIME);
    			} else {
    				printf("SetQHYCCDParam CONTROL_EXPOSURE failure, error: %d\n", retVal);
    				break;
    			}

    			// set image resolution
    			retVal = SetQHYCCDResolution(pCamHandle, roiStartX, roiStartY, roiSizeX, roiSizeY);
    			if (QHYCCD_SUCCESS == retVal) {
    				printf("SetQHYCCDResolution roiStartX x roiStartY  : %d x %d, success.\n", roiStartX, roiStartY);
    				printf("SetQHYCCDResolution roiSizeX  x roiSizeY   : %d x %d, success.\n", roiSizeX, roiSizeY);
    			} else {
    				printf("SetQHYCCDResolution failure, error: %d\n", retVal);
    				break;
    			}

    			// set binning mode
    			retVal = SetQHYCCDBinMode(pCamHandle, camBinX, camBinY);
    			if (QHYCCD_SUCCESS == retVal) {
    				printf("SetQHYCCDBinMode      set to: binX: %d, binY: %d, success.\n", camBinX, camBinY);
    			} else {
    				printf("SetQHYCCDBinMode failure, error: %d\n", retVal);
    				break;
    			}

    			// set bit resolution
    			retVal = IsQHYCCDControlAvailable(pCamHandle, CONTROL_TRANSFERBIT);
    			if (QHYCCD_SUCCESS == retVal) {
    				retVal = SetQHYCCDBitsMode(pCamHandle, 16);
    				if (QHYCCD_SUCCESS == retVal) {
    					printf("SetQHYCCDParam CONTROL_TRANSFERBIT   set to: %d, success.\n", CONTROL_TRANSFERBIT);
    				} else {
    					printf("SetQHYCCDParam CONTROL_TRANSFERBIT failure, error: %d\n", retVal);
    					break;
    				}
    			}

    			// single frame
    			printf("ExpQHYCCDSingleFrame(pCamHandle) - start...\n");
    			retVal = ExpQHYCCDSingleFrame(pCamHandle);
    			printf("ExpQHYCCDSingleFrame(pCamHandle) - end...\n");
    			if (QHYCCD_ERROR != retVal) {
    				printf("ExpQHYCCDSingleFrame success.\n");
    				if (QHYCCD_READ_DIRECTLY != retVal) {
    					sleep(1);
    				}
    			} else {
    				printf("ExpQHYCCDSingleFrame failure, error: %d\n", retVal);
    				break;
    			}

    			// get requested memory length
    			uint32_t length = GetQHYCCDMemLength(pCamHandle);
    			printf("Will try to allocate %d [uchar] data array for image.\n", length);

    			if (length > 0) {
    				pImgData = new unsigned char[length];
    				memset(pImgData, 0, length);
    				printf("SetQHYCCDParam CONTROL_EXPOSURE      set to: %d [us], success.\n", EXPOSURE_TIME);
    				printf("Allocated data array of %d [uchar].\n", length);
    			} else {
    				printf("Cannot allocate data array to store image data.\n");
    				break;
    			}

    			// get single frame, (i+1)
    			retVal = GetQHYCCDSingleFrame(pCamHandle, &roiSizeX, &roiSizeY, &bpp, &channels, pImgData);
    			if (QHYCCD_SUCCESS == retVal) {
    				printf("GetQHYCCDSingleFrame: %d x %d, bpp: %d, channels: %d, success.\n", roiSizeX, roiSizeY, bpp, channels);
    				//process image here
    			} else {
    				printf("GetQHYCCDSingleFrame failure, error: %d\n", retVal);
    			}

    			// delete image data
    			if (pImgData) {
    				delete [] pImgData;
    				pImgData = 0;
    			}
    			
    			retVal = CancelQHYCCDExposingAndReadout(pCamHandle);
    			if (QHYCCD_SUCCESS == retVal) {
    				printf("CancelQHYCCDExposingAndReadout success.\n");
    			} else {
    				printf("CancelQHYCCDExposingAndReadout failure, error: %d\n", retVal);
    				break;
    			}

    			// close camera handle
    			retVal = CloseQHYCCD(pCamHandle);
    			if (QHYCCD_SUCCESS == retVal) {
    				printf("CloseQHYCCD success.\n");
    			} else {
    				printf("CloseQHYCCD failure, error: %d\n", retVal);
    				break;
    			}
    		
    		} // for 
    	
    		if (pImgData) {
    			delete [] pImgData;
    			pImgData = 0;
    		}

    	} // for cycle
    	
    } while (0);
    		
    // Now, we have to call ReleaseQHYCCDResource function.
    // This function will first try to close all opened cameras, 
    // than release libusb and other sdk resources
    retVal = ReleaseQHYCCDResource();
    if (QHYCCD_SUCCESS == retVal) {
        printf("SDK resources released.\n");
    } else {
        printf("Cannot release SDK resources, error %d.\n", retVal);
    }

    return 0;
}
